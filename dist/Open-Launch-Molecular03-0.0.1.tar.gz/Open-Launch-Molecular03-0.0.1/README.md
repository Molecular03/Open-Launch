# Open-Launch
A work in progress, free and open source launch simulation for hobbyists and space enthusiasts.


### Quick-Version-Updates
Temporary folder for early stage code that will be updated often. 
New versions are created when big changes are integrated.

### main.py
Will eventually become the working version. 

A few more updates are needed before it can work as intended.
